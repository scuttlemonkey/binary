# OWL2CAT for Windows - Installation Guide

## Download

Download `owl2cat.exe` from the windows subdirectory of the provided SharePoint link and save it to your Downloads folder.

## Security Notice

When you first try to run owl2cat.exe, Windows Defender SmartScreen may show a warning:

> **"Windows protected your PC"**

This is normal! The tool isn't malicious - it just isn't code-signed with a Microsoft certificate.

To proceed:
1. Click **"More info"**
2. Click **"Run anyway"**

## Installation Steps

### Option 1: Run from Downloads (Quick Start)

1. Open Command Prompt or PowerShell
2. Navigate to your Downloads folder:
   ```cmd
   cd %USERPROFILE%\Downloads
   ```
3. Run the tool (see Usage section below)

### Option 2: Install to PATH (Recommended)

1. Create a folder for your tools:
   ```cmd
   mkdir C:\Users\%USERNAME%\bin
   ```

2. Move the executable there:
   ```cmd
   move %USERPROFILE%\Downloads\owl2cat.exe C:\Users\%USERNAME%\bin\owl2cat.exe
   ```

3. Add to PATH:
   - Press `Win + X` and select "System"
   - Click "Advanced system settings"
   - Click "Environment Variables"
   - Under "User variables", select "Path" and click "Edit"
   - Click "New" and add: `C:\Users\%USERNAME%\bin`
   - Click OK on all dialogs

4. Open a **new** Command Prompt and you can now run `owl2cat` from anywhere

## Usage

Set your data.world API token:

**Command Prompt:**
```cmd
set DW_TOKEN=your-api-token-here
```

**PowerShell:**
```powershell
$env:DW_TOKEN="your-api-token-here"
```

Convert and upload an OWL ontology:
```cmd
owl2cat.exe myontology.ttl my-module my-org
```

**Parameters:**
- `myontology.ttl` - Path to your OWL ontology file (Turtle format)
- `my-module` - Name for this ontology module
- `my-org` - data.world organization name

## Example

**Command Prompt:**
```cmd
set DW_TOKEN=eyJhbGc...
owl2cat.exe products.ttl products-catalog my-company
```

**PowerShell:**
```powershell
$env:DW_TOKEN="eyJhbGc..."
.\owl2cat.exe products.ttl products-catalog my-company
```

## Troubleshooting

**Windows Defender warning**
- Click "More info" then "Run anyway"
- Or: Right-click the file → Properties → Check "Unblock" → Apply

**"DW_TOKEN not set" error**
- Make sure you set the environment variable in the same command prompt window
- Environment variables don't persist between sessions unless you set them in System Properties

**"Command not found"**
- Use `.\owl2cat.exe` if running from current directory
- Or use the full path: `C:\Users\YourName\Downloads\owl2cat.exe`

**File paths with spaces**
- Use quotes: `owl2cat.exe "C:\My Files\ontology.ttl" my-module my-org`

## What it does

1. Reads your OWL ontology file (Turtle format)
2. Transforms it using 6 SPARQL queries to catalog metadata format
3. Uploads 3 files to `your-org/ddw-catalogs`:
   - `module_ontology.ttl` - Your original ontology
   - `module_owl2cat.ttl` - Transformed catalog metadata
   - `base.ttl` - Catalog metadata profile

## Questions?

Contact the Data Architecture team or check the main project repository.

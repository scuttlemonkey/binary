# OWL2CAT for macOS - Installation Guide

## Download

Download `owl2cat` from the MacOS subdirectory of the provided SharePoint link and save it to your Downloads folder.

## Security Notice

When you first try to run owl2cat, macOS will show a security warning:

> **"Apple could not verify 'owl2cat' is free of malware"**

This is normal! The tool isn't malicious - it just isn't code-signed with an Apple Developer certificate. You need to tell macOS to trust it.

## Installation Steps

### Method 1: Command Line (Recommended)

Open Terminal and run these commands:

```bash
cd ~/Downloads

# Remove the quarantine flag
xattr -d com.apple.quarantine owl2cat

# Make it executable
chmod +x owl2cat

# Optional: Move to a permanent location
mkdir -p ~/bin
mv owl2cat ~/bin/owl2cat
```

### Method 2: Using Finder

1. Open Finder and go to your Downloads folder
2. **Right-click** (or Control-click) on `owl2cat`
3. Select **"Open"** from the menu
4. In the warning dialog, click **"Open"**
5. The tool will run once, and macOS will remember your choice

Then make it executable:
```bash
cd ~/Downloads
chmod +x owl2cat
```

## Usage

Set your data.world API token:
```bash
export DW_TOKEN="your-api-token-here"
```

Convert and upload an OWL ontology:
```bash
./owl2cat myontology.ttl my-module my-org
```

**Parameters:**
- `myontology.ttl` - Path to your OWL ontology file (Turtle format)
- `my-module` - Name for this ontology module
- `my-org` - data.world organization name

## Example

```bash
export DW_TOKEN="eyJhbGc..."
./owl2cat products.ttl products-catalog my-company
```

## Troubleshooting

**"Permission denied"**
- Run: `chmod +x owl2cat`

**"Command not found"**
- Make sure you're in the directory containing owl2cat
- Or use the full path: `~/Downloads/owl2cat`

**Still getting security warnings?**
- Run: `xattr -d com.apple.quarantine owl2cat`

## What it does

1. Reads your OWL ontology file (Turtle format)
2. Transforms it using 6 SPARQL queries to catalog metadata format
3. Uploads 3 files to `your-org/ddw-catalogs`:
   - `module_ontology.ttl` - Your original ontology
   - `module_owl2cat.ttl` - Transformed catalog metadata
   - `base.ttl` - Catalog metadata profile

## Questions?

Contact the Data Architecture team or check the main project repository.

import os
import requests
import yaml
from argparse import ArgumentParser
from os import path

def create_project(owner, project_dir):
    print (f"Project dir {project_dir}")
    url = f"https://api.data.world/v0/projects/{owner}"

    payload = {"visibility": "OPEN"}
    
    files = ["summary.txt", "objective.txt", "title.txt"]
    for file in files:
        file_path = os.path.join(project_dir, file)
        if os.path.exists(file_path):
            file_content = read_file(file_path)
            payload[file.replace(".txt", "")] = file_content

    # for linked datasets
    yaml_file_path = os.path.join(project_dir, 'datasets.yaml')
    if os.path.exists(yaml_file_path):
        with open(yaml_file_path, "r") as yfile:
            linked_datasets = yaml.safe_load(yfile)

        if linked_datasets:
            payload["linkedDatasets"] = [{'id': ld.split('/')[-1], 'owner': ld.split('/')[0]}
                                        for ld in linked_datasets]

    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": f"Bearer {os.environ.get('DW_AUTH_TOKEN')}"
    }

    print (f"{url} {payload}")
    response = requests.post(url, json=payload, headers=headers)
    
    print(response.status_code, response.json())
    
    return response


def create_query(owner, project_name, project_dir, slug):
    for query_file in os.listdir(project_dir):
        if query_file.endswith('.ttl.rq'):            
            url = f"https://api.data.world/v0/datasets/{owner}/{project_name}/queries"
            
            file_content = read_file(os.path.join(project_dir, query_file)).format(pislug=slug)
            
            payload = {"content": file_content, "language": "SPARQL", "name": query_file}
            
            headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "authorization": f"Bearer {os.environ.get('DW_AUTH_TOKEN')}"
            }
            print (f"url {url} {payload}")
            response = requests.post(url, json=payload, headers=headers)
            
            print(response.status_code, response.json())


def read_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    return content
    
def get_owner_path(top_path):
    for dirname in os.listdir(top_path):
        if os.path.isdir(os.path.join(top_path, dirname)):
            yield dirname, os.path.join(top_path, dirname)

def get_directory(dataset_dir):
    for dirname in os.listdir(dataset_dir):
        yield dirname

def create_dataset(owner, dirname, dataset_dir):
    print (f"Create dataset {dirname} {dataset_dir}")
    url = f"https://api.data.world/v0/datasets/{owner}"

    payload = {"visibility": "OPEN"}
    
    files = ["summary.txt", "description.txt", "title.txt"]
    for file in files:
        file_path = os.path.join(dataset_dir, file)
        if os.path.exists(file_path):
            file_content = read_file(file_path)
            payload[file.replace(".txt", "")] = file_content

    headers = {
        "accept": "application/json",
        "content-type": "application/json",
        "authorization": f"Bearer {os.environ.get('DW_AUTH_TOKEN')}"
    }

    print (url, payload)
    response = requests.post(url, json=payload, headers=headers)
    
    print(response.status_code, response.json())
    

def main(pi_slug, top_path=os.getcwd()):

    
    for owner, path_dir in get_owner_path(top_path):
        for dataset_dir, dirnames, files in os.walk(path_dir):
            print (f"Checking for datasets.yaml in {dataset_dir}")
            if 'datasets.yaml' not in files and dataset_dir != path_dir:
                if dataset_dir != '.ipynb_checkpoints':
                    create_dataset(owner, dataset_dir, os.path.join(dataset_dir))
                        

    for owner, path_dir in get_owner_path(top_path):
        for project_dir, dirnames, files in os.walk(path_dir):
            if 'datasets.yaml' in files:
                if project_dir != '.ipynb_checkpoints':
                    project_path = os.path.join(project_dir)
                    print (f"project-dir {project_dir} | project_path {project_path}")
                    response = create_project(owner, project_path)
                    if response.status_code == 200:
                        
                        create_query(owner, response.json()['uri'].split('/')[-1], project_path, pi_slug)


                        
if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument('-s', '--slug', required=True, help='API slug')
    parser.add_argument('-p', '--path', default=os.getcwd(), help='Path for the directory')
    args = parser.parse_args()

    main(args.slug, args.path)

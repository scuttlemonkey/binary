#!/usr/bin/env python3
"""
OWL to Catalog CLI Tool
Converts OWL ontologies to data.world catalog format and uploads them.
"""

import sys
import os
import argparse
import requests
from rdflib import Graph
import json

def load_queries():
    """Load all SPARQL query files from the queries directory"""
    query_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'deploy-catalog')
    queries = []

    for filename in sorted(os.listdir(query_dir)):
        if filename.endswith('.rq'):
            with open(os.path.join(query_dir, filename), 'r') as f:
                queries.append((filename, f.read()))

    return queries, query_dir

def process_ontology(owl_file_path, module, dw_owner, token):
    """Process OWL file and upload to data.world"""

    # Load queries
    queries, query_dir = load_queries()

    # Read OWL file
    print(f"Reading OWL file: {owl_file_path}")
    with open(owl_file_path, 'r') as f:
        owl_content = f.read()

    # Parse with RDFLib
    print("Parsing OWL ontology...")
    input_graph = Graph()
    try:
        input_graph.parse(data=owl_content, format="ttl")
    except Exception as e:
        print(f"Error parsing OWL file: {e}", file=sys.stderr)
        return False

    print(f"Loaded {len(input_graph)} triples")

    # Prepare headers
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/octet-stream",
    }

    # Upload original ontology
    ontology_filename = f"{module}_ontology.ttl"
    print(f"\nUploading original ontology: {ontology_filename}")

    with open(ontology_filename, "w") as f:
        f.write(owl_content)

    ontology_upload_url = f"https://api.data.world/v0/uploads/{dw_owner}/ddw-catalogs/files/{ontology_filename}"

    with open(ontology_filename, "rb") as f:
        response = requests.put(ontology_upload_url, headers=headers, data=f)
        if response.status_code != 200:
            print(f"Error uploading ontology: {response.status_code} - {response.text}", file=sys.stderr)
            return False

    print(f"✓ Uploaded {ontology_filename}")

    # Run SPARQL transformations
    print("\nRunning SPARQL transformations...")
    output_graph = Graph()

    for query_name, query_text in queries:
        print(f"  Executing {query_name}...")
        try:
            result = input_graph.query(query_text)
            count = 0
            for triple in result:
                output_graph.add(triple)
                count += 1
            print(f"    Added {count} triples")
        except Exception as e:
            print(f"    Warning: Query {query_name} failed: {e}")

    print(f"Generated {len(output_graph)} catalog triples")

    # Upload transformed catalog
    output_filename = f"{module}_owl2cat.ttl"
    print(f"\nUploading transformed catalog: {output_filename}")

    output_graph.serialize(destination=output_filename, format="ttl")

    upload_url = f"https://api.data.world/v0/uploads/{dw_owner}/ddw-catalogs/files/{output_filename}"

    with open(output_filename, "rb") as f:
        response = requests.put(upload_url, headers=headers, data=f)
        if response.status_code != 200:
            print(f"Error uploading catalog: {response.status_code} - {response.text}", file=sys.stderr)
            return False

    print(f"✓ Uploaded {output_filename}")

    # Upload base.ttl if it exists
    base_file_path = os.path.join(query_dir, "base.ttl")
    if os.path.exists(base_file_path):
        print(f"\nUploading base.ttl...")
        base_upload_url = f"https://api.data.world/v0/uploads/{dw_owner}/ddw-catalogs/files/base.ttl"

        with open(base_file_path, "rb") as f:
            response = requests.put(base_upload_url, headers=headers, data=f)
            if response.status_code != 200:
                print(f"Warning: base.ttl upload failed: {response.status_code} - {response.text}")
            else:
                print(f"✓ Uploaded base.ttl")

    # Cleanup temp files
    try:
        os.remove(ontology_filename)
        os.remove(output_filename)
    except:
        pass

    return True

def main():
    parser = argparse.ArgumentParser(
        description='Convert OWL ontologies to data.world catalog format',
        epilog='Token must be set in DW_TOKEN environment variable'
    )

    parser.add_argument('owl_file', help='Path to OWL ontology file (TTL format)')
    parser.add_argument('module', help='Module name for output files')
    parser.add_argument('owner', help='Data.world organization owner')
    parser.add_argument('--version', action='version', version='owl2cat 1.0.1')

    args = parser.parse_args()

    # Get token from environment
    token = os.environ.get('DW_TOKEN')
    if not token:
        print("Error: DW_TOKEN environment variable not set", file=sys.stderr)
        print("\nSet your data.world API token:", file=sys.stderr)
        print("  export DW_TOKEN='your-token-here'", file=sys.stderr)
        sys.exit(1)

    # Check if file exists
    if not os.path.exists(args.owl_file):
        print(f"Error: File not found: {args.owl_file}", file=sys.stderr)
        sys.exit(1)

    print("=" * 60)
    print("OWL to Catalog Converter")
    print("=" * 60)
    print(f"File:   {args.owl_file}")
    print(f"Module: {args.module}")
    print(f"Owner:  {args.owner}")
    print("=" * 60)

    # Process and upload
    success = process_ontology(args.owl_file, args.module, args.owner, token)

    if success:
        print("\n" + "=" * 60)
        print("✓ SUCCESS")
        print("=" * 60)
        print(f"\nFiles uploaded to: https://data.world/{args.owner}/ddw-catalogs")
        print(f"  - {args.module}_ontology.ttl")
        print(f"  - {args.module}_owl2cat.ttl")
        print(f"  - base.ttl")
        sys.exit(0)
    else:
        print("\n" + "=" * 60)
        print("✗ FAILED")
        print("=" * 60)
        sys.exit(1)

if __name__ == "__main__":
    main()

# OWL2CAT for Linux - Installation Guide

## Download

Download `owl2cat` from the linux subdirectory of the provided SharePoint link and save it to your home directory or Downloads folder.

## Installation Steps

Open a terminal and run these commands:

```bash
cd ~/Downloads

# Make it executable
chmod +x owl2cat

# Optional: Move to a permanent location
sudo mv owl2cat /usr/local/bin/owl2cat
# OR for user-only installation:
mkdir -p ~/bin
mv owl2cat ~/bin/owl2cat
echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

## Usage

Set your data.world API token:
```bash
export DW_TOKEN="your-api-token-here"
```

Convert and upload an OWL ontology:
```bash
./owl2cat myontology.ttl my-module my-org
```

**Parameters:**
- `myontology.ttl` - Path to your OWL ontology file (Turtle format)
- `my-module` - Name for this ontology module
- `my-org` - data.world organization name

## Example

```bash
export DW_TOKEN="eyJhbGc..."
./owl2cat products.ttl products-catalog my-company
```

## Troubleshooting

**"Permission denied"**
- Run: `chmod +x owl2cat`

**"Command not found"**
- Make sure you're in the directory containing owl2cat
- Or use the full path: `~/Downloads/owl2cat`
- Or add `~/bin` to your PATH (see installation steps above)

**"No such file or directory" when running**
- Your system might be missing required libraries
- On Ubuntu/Debian: `sudo apt-get install libc6`
- On RHEL/CentOS: `sudo yum install glibc`

## What it does

1. Reads your OWL ontology file (Turtle format)
2. Transforms it using 6 SPARQL queries to catalog metadata format
3. Uploads 3 files to `your-org/ddw-catalogs`:
   - `module_ontology.ttl` - Your original ontology
   - `module_owl2cat.ttl` - Transformed catalog metadata
   - `base.ttl` - Catalog metadata profile

## Questions?

Contact the Data Architecture team or check the main project repository.

#!/bin/bash
# Build standalone executable with PyInstaller

set -e

echo "Installing dependencies..."
pip install -q pyinstaller rdflib requests

echo "Building standalone executable..."
pyinstaller \
  --onefile \
  --name owl2cat \
  --add-data "deploy-catalog/*.rq:deploy-catalog" \
  --add-data "deploy-catalog/base.ttl:deploy-catalog" \
  --clean \
  owl2cat_cli.py

echo ""
echo "Build complete!"
echo "Executable: dist/owl2cat"
echo ""
echo "Test it:"
echo "  export DW_TOKEN='your-token'"
echo "  ./dist/owl2cat test.ttl test-module your-org"

# Deploy Catalog

## Overview
`deploy_catalog` is a service that provisions a catalog in **data.world** from an OWL ontology file. It runs as a FastAPI application within a Docker container. The service takes the provided OWL file and:

- **Creates a catalog** in data.world with generic types corresponding to OWL classes.
- **Populates the catalog** with members based on OWL class instances.
- **Organizes items** into a collection named after the provided `module` parameter.
- **Deploys the catalog** in the organization specified by `dw_owner`, within the project identified by `service_name`.

## Deployment

### Prerequisites
- Docker installed on your system
- A valid `data.world` account with appropriate API credentials
- A properly formatted OWL ontology file
- **A dataset named `ddw-catalogs` must already exist in your data.world organization** (e.g., `my-org/ddw-catalogs`). The service uploads files to this dataset but does not create it.
- **The API token must have Contribute access** to the `ddw-catalogs` dataset.

### Environment Variables
The service relies on an authentication secrets file (`/etc/secrets/auth.json`) for API tokens. The file is a **JSON key-value store**, mapping `service_name` values to authentication tokens:

```json
{
    "dataworld_project1": "abc123token",
    "another_service": "xyz789token"
}
```
Ensure this file is available and readable by the container.

## Running the Service

### Docker Command
To run the service:
```sh
docker run -v /etc/secrets/auth.json:/etc/secrets/auth.json -p 8080:8080 deploy_catalog
```

### API Usage
#### Endpoint: `POST /upload-ontology`
Uploads an OWL file and provisions a catalog in data.world.

**Request Body (JSON):**
```json
{
    "owl_file": "<OWL file content>",
    "module": "example_module",
    "dw_owner": "example_owner",
    "service_name": "dataworld_project1"
}
```

**Parameters:**
- `owl_file`: The ontology file content in **Turtle (TTL) format**.
- `module`: The collection name in which items will be organized.
- `dw_owner`: The data.world **organization** where the catalog is created.
- `service_name`: Identifies which API token (from `/etc/secrets/auth.json`) to use.

**Response:**
```json
{
    "message": "Processing complete",
    "files": ["example_module_ontology.ttl"]
}
```

## Error Handling
- **403 Forbidden**: The `service_name` is invalid or missing from `/etc/secrets/auth.json`.
- **500 Internal Server Error**: Issues processing the OWL file or connecting to data.world.
- **401 Unauthorized**: Missing or incorrect authentication token.

## Development & Debugging
- Ensure `auth.json` is correctly formatted and contains valid API tokens.
- Run locally with `uvicorn`:
```sh
uvicorn app:app --reload --host 0.0.0.0 --port 8080
```
- Check logs for errors when provisioning catalogs in `data.world`.

## Future Enhancements
- Add support for additional ontology formats (e.g., RDF/XML, JSON-LD)
- Improved logging and error diagnostics

## License
MIT License


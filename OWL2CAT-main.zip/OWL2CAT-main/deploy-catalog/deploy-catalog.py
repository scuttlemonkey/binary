from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import json
import os
import requests
from rdflib import Graph

app = FastAPI()

# Load service tokens from Heroku environment variable
AUTH_JSON_ENV = os.environ.get("AUTH_JSON")

if not AUTH_JSON_ENV:
    raise FileNotFoundError("Critical Error: AUTH_JSON environment variable not found. Ensure it is set in Heroku.")

try:
    SERVICE_TOKENS = json.loads(AUTH_JSON_ENV)  # Read JSON data from environment variable
except json.JSONDecodeError:
    raise ValueError("Invalid JSON format in AUTH_JSON environment variable. Check variable content.")




class OWLFilePayload(BaseModel):
    owl_file: str
    module: str
    dw_owner: str
    service_name: str  # New argument: which service's token to use

@app.post("/upload-ontology")
async def upload_ontology(payload: OWLFilePayload):
    """
    Accepts OWL file, processes it with RDFLib, and uploads to a service using the correct token from the secrets file.
    """
    service_name = payload.service_name  # Identify the service
    
    # Retrieve token from the loaded secrets
    token = SERVICE_TOKENS.get(service_name)
    if not token:
        raise HTTPException(status_code=403, detail="Unauthorized: Invalid service name or token not registered")

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/octet-stream",
    }

    
    try:
        ontology_filename = f"{payload.module}_ontology.ttl"
        output_filename = f"{payload.module}_owl2cat.ttl"

        input_graph = Graph()
        input_graph.parse(data=payload.owl_file, format="ttl")

        with open(ontology_filename, "w") as ontology_file:
            ontology_file.write(payload.owl_file)

        ontology_upload_url = f"https://api.data.world/v0/uploads/{payload.dw_owner}/ddw-catalogs/files/{ontology_filename}"
        print (f"""first ontology upload {ontology_upload_url}""")
        print("DEBUG: Headers being sent:", headers)
        
        with open(ontology_filename, "rb") as file:
            ontology_response = requests.put(ontology_upload_url, headers=headers, data=file)
            if ontology_response.status_code != 200:
                raise HTTPException(
                    status_code=ontology_response.status_code,
                    detail=f"Data.world upload failed: {ontology_response.text}"
                )

        query_dir = os.path.dirname(os.path.abspath(__file__))
        output_graph = Graph()

        for query_file in os.listdir(query_dir):
            if query_file.endswith(".rq"):
                with open(os.path.join(query_dir, query_file), "r") as qf:
                    query = qf.read()
                    result = input_graph.query(query)
                    
                    for triple in result:
                        output_graph.add(triple)

        output_graph.serialize(destination=output_filename, format="ttl")

        upload_url = f"https://api.data.world/v0/uploads/{payload.dw_owner}/ddw-catalogs/files/{output_filename}"
        print (f"""second file upload {upload_url}""")
        print("DEBUG: Headers being sent:", headers)

        with open(output_filename, "rb") as file:
            response = requests.put(upload_url, headers=headers, data=file)
            if response.status_code != 200:
                raise HTTPException(
                    status_code=response.status_code,
                    detail=f"Data.world upload failed: {response.text}"
                )

        # Upload base.ttl if it exists
        base_file_path = os.path.join(query_dir, "base.ttl")
        if os.path.exists(base_file_path):
            base_upload_url = f"https://api.data.world/v0/uploads/{payload.dw_owner}/ddw-catalogs/files/base.ttl"
            print(f"""base.ttl upload {base_upload_url}""")
            with open(base_file_path, "rb") as file:
                base_response = requests.put(base_upload_url, headers=headers, data=file)
                if base_response.status_code != 200:
                    print(f"Warning: base.ttl upload failed: {base_response.text}")

        return {"message": "Processing complete", "files": [ontology_filename]}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing ontology: {str(e)}")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))  # Get the Heroku-assigned port
    uvicorn.run(app, host="0.0.0.0", port=port)

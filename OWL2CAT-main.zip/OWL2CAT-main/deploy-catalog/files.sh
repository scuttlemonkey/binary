./upload.sh /Users/dean.allemang/github/OWL2CAT/deploy-catalog/DEA-data/dea-individualsRE.ttl individualsRE fedsys fedsys
./upload.sh /Users/dean.allemang/github/OWL2CAT/deploy-catalog/DEA-data/dea-node-commodityRE.ttl node-commodityRE fedsys fedsys
./upload.sh /Users/dean.allemang/github/OWL2CAT/deploy-catalog/DEA-data/dea-node-facilityRE.ttl node-facilityRE fedsys fedsys
./upload.sh /Users/dean.allemang/github/OWL2CAT/deploy-catalog/DEA-data/dea-node-fin-accountRE.ttl node-fin-accountRE fedsys fedsys
./upload.sh /Users/dean.allemang/github/OWL2CAT/deploy-catalog/DEA-data/dea-node-routeRE.ttl node-routeRE fedsys fedsys
./upload.sh /Users/dean.allemang/github/OWL2CAT/deploy-catalog/DEA-data/dea-ontologyRE.ttl ontologyRE fedsys fedsys

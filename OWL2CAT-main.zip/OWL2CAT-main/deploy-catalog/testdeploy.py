from rdflib import Graph
import os



ontology_filename = f"skolem_ontology.ttl"
output_filename = f"skolem_owl2cat.ttl"

input_graph = Graph()
input_graph.parse("test.ttl", format="ttl")

query_dir = os.path.dirname(os.path.abspath(__file__))
output_graph = Graph()

for query_file in os.listdir(query_dir):
    if query_file.endswith(".rq"):
        with open(os.path.join(query_dir, query_file), "r") as qf:
            query = qf.read()
            result = input_graph.query(query)
            
            for triple in result:
                output_graph.add(triple)

output_graph.serialize(destination=output_filename, format="ttl")


#!/bin/bash

# Usage: ./upload.sh <ontology-file.ttl> <module-name> <owner> <service-name>

if [ "$#" -ne 4 ]; then
    echo "Usage: $0 <ontology-file.ttl> <module-name> <owner> <service-name>"
    echo "Example: $0 my-ontology.ttl my-module fedsys fedsys"
    exit 1
fi

OWL_FILE="$1"
MODULE="$2"
OWNER="$3"
SERVICE="$4"

if [ ! -f "$OWL_FILE" ]; then
    echo "Error: File $OWL_FILE not found"
    exit 1
fi

# Read file and escape for JSON (replace backslash, quote, newline, etc.)
OWL_CONTENT=$(sed 's/\\/\\\\/g; s/"/\\"/g' "$OWL_FILE" | awk '{printf "%s\\n", $0}' | sed '$ s/\\n$//')

# Create JSON payload
cat > /tmp/payload.json << EOF
{
  "owl_file": "$OWL_CONTENT",
  "module": "$MODULE",
  "dw_owner": "$OWNER",
  "service_name": "$SERVICE"
}
EOF

# Send to API
curl -X POST https://owl2cat-deploy-7992033fef27.herokuapp.com/upload-ontology \
  -H "Content-Type: application/json" \
  -d @/tmp/payload.json

echo ""

# OWL2CAT - OWL to Catalog Converter

Convert OWL ontologies to data.world catalog metadata format.

## Two Deployment Options

### 1. Standalone CLI Tool (Recommended for End Users)

Download a single executable - no Python, jq, or other dependencies needed!

#### Quick Start

**Prerequisites:**
1. Create a dataset named `ddw-catalogs` in your data.world organization (e.g., `my-org/ddw-catalogs`)
2. Ensure the user associated with your API token has **Contribute** access to the `ddw-catalogs` dataset
3. The tool will upload files to this dataset - it will NOT create the dataset automatically

```bash
# Download for your platform
# macOS:
curl -L https://github.com/datadotworld/OWL2CAT/releases/latest/download/owl2cat-macos -o owl2cat
chmod +x owl2cat

# Linux:
curl -L https://github.com/datadotworld/OWL2CAT/releases/latest/download/owl2cat-linux -o owl2cat
chmod +x owl2cat

# Windows:
# Download owl2cat-windows.exe from releases page

# Set your data.world API token
export DW_TOKEN="your-api-token-here"

# Convert and upload your ontology
./owl2cat myontology.ttl my-module my-org
```

#### What It Does

1. Reads your OWL ontology file (Turtle format)
2. Transforms it using 6 SPARQL queries to catalog metadata format
3. Uploads 3 files to `your-org/ddw-catalogs`:
   - `module_ontology.ttl` - Your original ontology
   - `module_owl2cat.ttl` - Transformed catalog metadata
   - `base.ttl` - Catalog metadata profile

**Important:** The `ddw-catalogs` dataset must already exist in your organization, and your API token must have **Contribute** access to it. The tool does not create datasets.

#### CLI Usage

```bash
owl2cat <ontology.ttl> <module-name> <org-name>
```

**Parameters:**
- `ontology.ttl` - Path to your OWL ontology file (Turtle format)
- `module-name` - Name for this ontology module (used in output filenames)
- `org-name` - data.world organization owner

**Environment:**
- `DW_TOKEN` - Your data.world API token (required)

**Example:**
```bash
export DW_TOKEN="eyJhbGc..."
./owl2cat products.ttl products-catalog acme-corp
```

### 2. Cloud Service (For GPT Integration)

A Heroku-hosted REST API for programmatic access.

**Prerequisites:** The `ddw-catalogs` dataset must exist in your data.world organization, and the service account must have **Contribute** access to it.

#### Service Endpoint

```
POST https://owl2cat-deploy-7992033fef27.herokuapp.com/upload-ontology
```

#### API Usage

**Using jq (recommended):**
```bash
jq -n --rawfile owl myfile.ttl \
  '{owl_file: $owl, module: "my-module", dw_owner: "my-org", service_name: "my-service"}' | \
curl -X POST https://owl2cat-deploy-7992033fef27.herokuapp.com/upload-ontology \
  -H "Content-Type: application/json" \
  -d @-
```

**Using Python:**
```python
import requests
import json

with open('myontology.ttl', 'r') as f:
    owl_content = f.read()

response = requests.post(
    'https://owl2cat-deploy-7992033fef27.herokuapp.com/upload-ontology',
    json={
        'owl_file': owl_content,
        'module': 'my-module',
        'dw_owner': 'my-org',
        'service_name': 'my-service'
    }
)
print(response.json())
```

**Request Body:**
```json
{
  "owl_file": "<OWL content in Turtle format>",
  "module": "module-name",
  "dw_owner": "organization-name",
  "service_name": "service-account-name"
}
```

The service supports multiple data.world instances via configured service accounts.

---

## Developer Documentation

### Building from Source

#### Prerequisites
- Python 3.9+
- PyInstaller

#### Build Standalone Executable

```bash
./build.sh
```

This creates `dist/owl2cat` - a single executable with all dependencies bundled.

#### GitHub Releases

When you push a git tag, GitHub Actions automatically builds executables for Mac, Linux, and Windows:

```bash
git tag v1.0.0
git push origin v1.0.0
```

Binaries appear at: https://github.com/datadotworld/OWL2CAT/releases

### CTK-Based Infrastructure Deployment

For enterprise CTK deployments:

#### deploy.py - CTK Infrastructure Setup

Deploys OWL2CAT capability into a data.world Private Instance with existing CTK stack.

**Synopsis:**
```bash
python deploy.py -s <slug> -p <path>
```

**Options:**
- `-s, --slug` [REQUIRED]: Name of the data.world Private Instance (PI)
- `-p, --path` [OPTIONAL]: Path to directory (defaults to current directory)

**Requirements:**
- CTK stack already deployed in the PI
- Base orgs match template directories: `catalog-sources` and `catalog-config`

**Example:**
```bash
python deploy.py -s my-instance -p /path/to/templates
```

This creates datasets, queries, and documentation for ongoing OWL catalog management.

### Architecture

The project contains two complementary implementations:

1. **deploy-catalog/** - Direct API service (FastAPI)
   - Standalone transformation and upload
   - No CTK dependency
   - Used by Heroku service and CLI tool

2. **deploy.py + templates/** - CTK infrastructure deployment
   - Creates reusable catalog management framework
   - Requires pre-existing CTK stack
   - One-time setup for enterprise use

Both use the same core SPARQL transformation queries in `deploy-catalog/*.rq`.

---

## SPARQL Transformations

The converter runs 6 SPARQL queries to transform OWL to catalog format:

1. **owlcat.ttl.rq** - Creates RelationshipPresentations from object properties
2. **owlcatattributes.ttl.rq** - Extracts datatype properties as attributes
3. **owlcatident.ttl.rq** - Generates identifiers and enables UI creation
4. **instances.ttl.rq** - Creates CatalogRecords for instances
5. **inferences.ttl.rq** - Processes inferred relationships
6. **label.rq** - Preprocesses labels (rdfs:label, hasName, etc.)

Plus **base.ttl** - Catalog metadata profile foundation (sections, status classes)

---

## License

MIT License

---

## Support

For issues and questions: https://github.com/datadotworld/OWL2CAT/issues
